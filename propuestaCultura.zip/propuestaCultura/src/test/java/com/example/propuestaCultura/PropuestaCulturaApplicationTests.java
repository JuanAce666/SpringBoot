package com.example.propuestaCultura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PropuestaCulturaApplicationTests {

	@Test
	void contextLoads() {
	}

}
